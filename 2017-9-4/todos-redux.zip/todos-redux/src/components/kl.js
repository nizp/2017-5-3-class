import React,{Component} from "react";
export default class Kl extends Component{
    constructor(props){
        super(props);
    }

    render(){
        return (
            <div>
                KL
            </div>
        )
    }
}
