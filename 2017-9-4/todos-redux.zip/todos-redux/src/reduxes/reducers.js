import view from '../components/footer/FooterRedux';
import data from '../components/main/BodyRedux';
import val from '../components/header/HeaderRedux';

export default{
    view,
    data,
    val
}

// push('/detail')

// rootReducer <= viewReducer <= compnentRedex

// import homeData from '../view/home/HomeRedux';
//
// export default{
//
//     homeData
// }
