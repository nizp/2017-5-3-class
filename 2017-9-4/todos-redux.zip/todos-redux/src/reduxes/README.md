
configureStore 用来创建store

reducers 导出所有视图级别的 reducer

home 组件 HomeRedux
    aa, AaRedux.js  / actionTypes actionCreators reducer
    bb,
    cc, CcRedux / actionTypes actionCreators reducer
