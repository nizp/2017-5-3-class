

export default class Home extends Component{
    constructor(props){
        super(props);
    }

    render(){
        return (
            <div>
                <Nav></Nav>
                <Table></Table>

            </div>
        )
    }
}
